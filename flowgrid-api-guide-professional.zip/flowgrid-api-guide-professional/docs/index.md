# FlowGrid Help Centre

## Connecting External Webhooks and HTTP Request Nodes

FlowGrid integrations use standard HTTPS requests with JSON payloads. This documentation describes the HTTP format, required headers, authentication example, successful response, and common error codes.

### Documentation

1. [Integration Guide](integration-guide.md)
2. [HTTP Reference](reference/http.md)
3. [Error Reference](reference/errors.md)
4. [OpenAPI Specification](../openapi/openapi.yaml)

### Scope

This documentation covers the fictional FlowGrid HTTP integration example provided for this project. It does not establish access rights or authorization for any external developer or software system.
