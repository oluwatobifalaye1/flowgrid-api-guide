# Integration Guide

## Overview

FlowGrid provides a webhook-style HTTP integration model for receiving events from external systems. Requests are sent over HTTPS using JSON.

## Authentication

The example request uses a Bearer authorization header:

```http
Authorization: Bearer fg_live_example_token
```

The value shown is a placeholder. It must not be treated as a real credential.

## Request headers

| Header | Required | Purpose |
|---|---|---|
| `Authorization` | Yes | Supplies the example Bearer credential. |
| `Content-Type` | Yes | Identifies the request body as JSON. |
| `X-FlowGrid-Signature` | Yes | Provides the example request signature. |

## Sending an event

Example request:

```http
POST /v1/hooks/catch/wf_98234712 HTTP/1.1
Host: api.flowgrid.io
Authorization: Bearer fg_live_example_token
Content-Type: application/json
X-FlowGrid-Signature: sha256=example_signature
```

Request body:

```json
{
  "event": "lead.created",
  "lead_name": "Jordan Lee",
  "email": "jordan@example.com"
}
```

## Successful response

A request that is accepted returns:

```http
HTTP/1.1 200 OK
Content-Type: application/json
```

```json
{
  "success": true,
  "execution_id": "exec_784215",
  "status": "accepted"
}
```

## cURL example

```bash
curl -X POST "https://api.flowgrid.io/v1/hooks/catch/wf_98234712"   -H "Authorization: Bearer fg_live_example_token"   -H "Content-Type: application/json"   -H "X-FlowGrid-Signature: sha256=example_signature"   -d '{
    "event": "lead.created",
    "lead_name": "Jordan Lee",
    "email": "jordan@example.com"
  }'
```

## Implementation boundary

This guide documents the HTTP structure supplied for the fictional FlowGrid example. It does not document a real authentication service, permission model, SDK, or third-party software connection. Where a production implementation requires additional security or authorization details, those details must be supplied by the actual service owner.
