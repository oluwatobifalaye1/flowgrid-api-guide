# Error Reference

| HTTP Code | Error | Meaning | Recommended action |
|---:|---|---|---|
| `400` | Bad Request | Invalid payload, parameters, or signature. | Check the JSON payload and headers. |
| `401` | Unauthorized | Missing, expired, or invalid credentials. | Check the authorization header. |
| `403` | Forbidden | Valid credentials but insufficient permission. | Review workspace roles. |
| `404` | Not Found | Resource or endpoint does not exist. | Confirm the URL and resource ID. |
| `409` | Conflict | Request conflicts with the current state. | Refresh and retry. |
| `413` | Payload Too Large | Request exceeds the payload-size limit. | Reduce the payload or use storage URLs. |
| `422` | Unprocessable Entity | Valid JSON but invalid field values. | Review required fields and formats. |
| `429` | Too Many Requests | Rate limit exceeded. | Retry after the indicated period. |
| `500` | Internal Server Error | Unexpected processing error. | Retry and contact support. |
| `502` | Bad Gateway | Upstream integration returned an invalid response. | Check the external service and retry. |
| `503` | Service Unavailable | Service is temporarily unavailable. | Retry after a short interval. |
| `504` | Gateway Timeout | Execution exceeded the time limit. | Use asynchronous processing or smaller operations. |
