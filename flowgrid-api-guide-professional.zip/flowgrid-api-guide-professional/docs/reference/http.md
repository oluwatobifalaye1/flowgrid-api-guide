# HTTP Reference

## Endpoint

```text
POST https://api.flowgrid.io/v1/hooks/catch/wf_98234712
```

### Headers

```http
Authorization: Bearer fg_live_example_token
Content-Type: application/json
X-FlowGrid-Signature: sha256=example_signature
```

### Request body

```json
{
  "event": "lead.created",
  "lead_name": "Jordan Lee",
  "email": "jordan@example.com"
}
```

### Request properties

| Property | Type | Description |
|---|---|---|
| `event` | string | Event name. The example uses `lead.created`. |
| `lead_name` | string | Name associated with the example lead event. |
| `email` | string | Email associated with the example lead event. |

## Response

### 200 OK

```json
{
  "success": true,
  "execution_id": "exec_784215",
  "status": "accepted"
}
```

| Property | Type | Description |
|---|---|---|
| `success` | boolean | Indicates that the request was accepted. |
| `execution_id` | string | Identifier assigned to the example workflow execution. |
| `status` | string | Processing state returned by the example API. |
